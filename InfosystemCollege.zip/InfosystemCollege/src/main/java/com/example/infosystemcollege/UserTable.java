package com.example.infosystemcollege;

import javafx.beans.property.*;

public class UserTable {
    public StringProperty idProperty() {
        return id;
    }

    public StringProperty predmetProperty() {
        return predmet;
    }
    public StringProperty namestudentProperty() {
        return namestudent;
    }
    public StringProperty ocenkaProperty() {
        return ocenka;
    }
    public StringProperty id = new SimpleStringProperty();
    public StringProperty predmet = new SimpleStringProperty();
    public StringProperty namestudent = new SimpleStringProperty();
    public StringProperty ocenka = new SimpleStringProperty();

    public UserTable(int id, String namestudent, String predmet, String ocenka) {
        this.id.setValue(String.valueOf(id));
        this.predmet.setValue(predmet);
        this.namestudent.setValue(namestudent);
        this.ocenka.setValue(ocenka);
    }


}
