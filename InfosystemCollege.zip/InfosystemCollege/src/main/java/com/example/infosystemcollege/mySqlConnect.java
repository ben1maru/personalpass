package com.example.infosystemcollege;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class mySqlConnect {
    Connection conn =null;
    public static Connection ConnectDb() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/opicollegephk?useUnicode=true&characterEncoding=utf8","root", "");
            JOptionPane.showMessageDialog(null, "ConnectionEstablished");
            return conn;
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null,e);
        return null;
        }
    }
    public static ObservableList <UserTable> getDataUsersTable(){

        Connection conn = ConnectDb();
        ObservableList <UserTable> list = FXCollections.observableArrayList();
        try {
               PreparedStatement ps = conn.prepareStatement("select * from `ocenki`");
               ResultSet rs= ps.executeQuery();

               while (rs.next()){
                   list.add(new UserTable(Integer.parseInt(rs.getString("id_ocenki")), rs.getString("namestudent"),rs.getString("predmet"),rs.getString("ocenka")));
               }
        }catch (Exception e){
        }
        return list;
    }
}
