package com.example.infosystemcollege;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.net.URI;
import java.net.URISyntaxException;
import java.awt.Desktop;

public class Menu {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button isUser;

    @FXML
    private Button aboutCollege;

    @FXML
    private Button progress;

    @FXML
    private Button exit;

    @FXML
    private Button aboutProgram;

    @FXML
    void initialize() {
        aboutProgram.setOnAction(event->{
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Про додаток!");
                alert.setHeaderText("Ви користуєтесь бета версією програми і вона не працює як належне і найближчим часом все буде готово");
                alert.setContentText("Інформаційна система коледжу розроблена студентом КН-31 Бабич Євген");
                alert.showAndWait();

        });


        aboutCollege.setOnAction(Event -> {
            try {

                Desktop.getDesktop().browse(new URI("https://www.college.uzhnu.edu.ua/koledzh"));

            } catch (IOException | URISyntaxException e1) {
                e1.printStackTrace();
            }
        });
        isUser.setOnAction(Event ->{

            Stage stage = (Stage) isUser.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("LogIn.fxml"));
            try{
                loader.load();
            }catch (IOException e){
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            stage.setScene(new Scene(root));
        });
        progress.setOnAction(Event -> {
            progress.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("progressMenu.fxml"));
            try {
                loader.load();
            }catch (IOException e){
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage =new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait();
        });
        exit.setOnAction(Event -> {
         isUser.getScene().getWindow().hide();
});
    }
}
