package com.example.infosystemcollege;

public class Const {
    public static final String STUDENT_TABLE = "students";
    public static final String STUDENT_ID = "id";
    public static final String STUDENT_STUDENTNAME = "`studentname`";
    public static final String STUDENT_PASSWORD = "`password`";
    public static final String STUDENT_ADDRESS = "`address`";
    public static final String STUDENT_EMAIL = "`email`";
    public static final String STUDENT_SPECIALNIST = "`specialnist`";
    public static final String STUDENT_GROUP = "`namegroup`";
    public static final String STUDENT_NUMBERPHONE = "`numberphone`";
    public static final String STUDENT_LOGIN = "`login`";
}
