package com.example.infosystemcollege;


import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Stack;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;

public class progressWin implements Initializable {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    ///////////////
    @FXML
    private TableView<UserTable> table;
    @FXML
    private TableColumn<UserTable, String> tableIdColumn;
    @FXML
    private TableColumn<UserTable, String> tableLessonColumn;
    @FXML
    private TableColumn<UserTable, String> tableUsernameColumn;
    @FXML
    private TableColumn<UserTable, String> tableMarkColumn;
    @FXML
    private Button addMark;
    @FXML
    private Button updateMark;
    @FXML
    private Button deleteMark;
    ////////////
    @FXML
    private TextField isNameStudent;
    @FXML
    private TextField isLesson;
    @FXML
    private TextField isMark;
    @FXML
    private Button isBackBtn;

    //////////////////
    ObservableList<UserTable> listM;
    int index = -1;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    @FXML
    private void setAddMark(){
        conn=mySqlConnect.ConnectDb();
        String sql = "insert into ocenki (namestudent,predmet,ocenka)values(?,?,?)";
        try{
            pst= conn.prepareStatement(sql);
           pst.setString(1,isNameStudent.getText());
            pst.setString(2,isLesson.getText());
            pst.setString(3,isMark.getText());
            pst.execute();

            JOptionPane.showMessageDialog(null,"Ocenka dodana");
            UpdateTable();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UpdateTable();
        updateMark.setOnAction(actionEvent -> {
            Edit();
        });
        deleteMark.setOnAction(actionEvent -> {
            DeleteUser();
        });
        isBackBtn.setOnAction(actionEvent -> {
            Stage stage = (Stage) isBackBtn.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Menu.fxml"));
            try{
                loader.load();
            }catch (IOException e){
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            stage.setScene(new Scene(root));
        });

    }
    public void UpdateTable(){
        tableIdColumn.setCellValueFactory(param -> param.getValue().idProperty());
        tableUsernameColumn.setCellValueFactory(param -> param.getValue().namestudentProperty());
        tableLessonColumn.setCellValueFactory(param -> param.getValue().predmetProperty());
        tableMarkColumn.setCellValueFactory(param -> param.getValue().ocenkaProperty());
        listM =mySqlConnect.getDataUsersTable();
        table.setItems(listM);
        ////////////////////////////
    }
public void Edit(){
        try {
            conn= mySqlConnect.ConnectDb();
            String value1 = isNameStudent.getText();
            String value2 = isLesson.getText();
            String value3 = isMark.getText();

            String sql = "update ocenki set namestudent= '"+ value1 +"',predmet= '"+value2+"',ocenka= '"+ value3+"' where  namestudent= '"+ value1 +"' ";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null,"Дані оновлено");
            UpdateTable();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
}
    public void getSelect(javafx.scene.input.MouseEvent mouseEvent) {
        index = table.getSelectionModel().getSelectedIndex();
        if(index <= -1){
            return;
        }
        isNameStudent.setText(tableUsernameColumn.getCellData(index));
        isLesson.setText(tableLessonColumn.getCellData(index));
        isMark.setText(tableMarkColumn.getCellData(index));
    }
    public void DeleteUser(){
        conn=mySqlConnect.ConnectDb();
        String sql = "delete from ocenki where namestudent = ? ";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1,isNameStudent.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Видалено");
            UpdateTable();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }
}
