package com.example.infosystemcollege;

import javafx.fxml.FXML;
import java.util.Arrays;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.stage.Stage;

import javax.swing.*;

public class windowReg {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField login;

    @FXML
    private TextField email;

    @FXML
    private PasswordField password;

    @FXML
    private Button signUp;

    @FXML
    private TextField spec;

    @FXML
    private TextField group;

    @FXML
    private TextField address;

    @FXML
    private TextField Name;

    @FXML
    private TextField numberPhone;

    @FXML
    private Button isBack;

    @FXML
    void initialize() {
        DatabaseHandler databaseHandler = new DatabaseHandler();
        signUp.setOnAction(event ->{
            signUpNewUser();

        } );
        isBack.setOnAction(event ->{
            isBack.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Menu.fxml"));
            try {
                loader.load();
            }catch (IOException e){
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage =new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait();
        });
    }

    private void signUpNewUser() {
        DatabaseHandler databaseHandler = new DatabaseHandler();
        String studentName = Name.getText();
        String passwordReg = password.getText();
        String addressReg = address.getText();
        String emailReg = email.getText();
        String specialnist = spec.getText();
        String groupReg = group.getText();
        String numberphone = numberPhone.getText();
        String loginReg = login.getText();
        ArrayList<String> arrList = new ArrayList<String>();
        arrList.addAll(Arrays.asList( studentName,passwordReg,addressReg,emailReg,specialnist,groupReg,numberphone,loginReg));
        if (arrList.stream().anyMatch(text -> text.equals(""))){
            JOptionPane.showMessageDialog(null,"Введіть всі значення");
            return;
        }
        User user = new User(studentName,passwordReg,addressReg,emailReg,specialnist,groupReg,numberphone,loginReg);
        databaseHandler.signUpUser(user);
    }
}
