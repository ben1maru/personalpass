package com.example.infosystemcollege;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;



public class DatabaseHandler {
    Connection dbConnection;

    public Connection getDbConnection() throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.cj.jdbc.Driver");
        dbConnection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/opicollegephk?useUnicode=true&characterEncoding=utf8","root", "");
        System.out.println(dbConnection);
        return dbConnection;

    }

    public void signUpUser(User user) {
        String insert = "INSERT INTO " + Const.STUDENT_TABLE + "(" +
                Const.STUDENT_STUDENTNAME + "," + Const.STUDENT_ADDRESS + "," +
                Const.STUDENT_NUMBERPHONE + "," + Const.STUDENT_EMAIL + "," +
                Const.STUDENT_SPECIALNIST + "," + Const.STUDENT_LOGIN + "," +
                Const.STUDENT_PASSWORD + "," + Const.STUDENT_GROUP + ")" + "VALUES(?,?,?,?,?,?,?,?)";


        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(insert);
            prSt.setString(1, user.getStudentName());
            prSt.setString(2, user.getAddress());
            prSt.setString(3, user.getNumberphone());
            prSt.setString(4, user.getEmail());
            prSt.setString(5, user.getSpecialnist());
            prSt.setString(6, user.getLogin());
            prSt.setString(7, user.getPassword());
            prSt.setString(8, user.getGroup());
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public ResultSet getUser(User user) {
        ResultSet resSet = null;
        String select = "SELECT * FROM "+Const.STUDENT_TABLE+ " WHERE "+Const.STUDENT_LOGIN +" =? AND"+ Const.STUDENT_PASSWORD + "=?";
        try {

            PreparedStatement prSt = getDbConnection().prepareStatement(select);
            prSt.setString(1, user.getLogin());
            prSt.setString(2, user.getPassword());
            resSet = prSt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return resSet;
    }
}




