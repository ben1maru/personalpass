package com.example.infosystemcollege;

public class User {
    private String studentName;
    private String password;
    private String address;
    private String email;
    private String specialnist;
    private String group;
    private String  numberphone;
    private String  login;

    public User(String studentName, String password, String address, String email, String specialnist, String group, String numberphone, String login) {
        this.studentName = studentName;
        this.password = password;
        this.address = address;
        this.email = email;
        this.specialnist = specialnist;
        this.group = group;
        this.numberphone = numberphone;
        this.login = login;
    }

    public User() {}

    public String getStudentName() {
        return studentName;
    }

    public String getPassword() {
        return password;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getSpecialnist() {
        return specialnist;
    }

    public String getGroup() {
        return group;
    }

    public String getNumberphone() {
        return numberphone;
    }

    public String getLogin() {
        return login;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSpecialnist(String specialnist) {
        this.specialnist = specialnist;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public void setNumberphone(String numberphone) {
        this.numberphone = numberphone;
    }

    public void setLogin(String login) {
        this.login = login;
    }


}
