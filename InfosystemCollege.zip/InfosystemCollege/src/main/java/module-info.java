module com.example.infosystemcollege {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;


    opens com.example.infosystemcollege to javafx.fxml;
    exports com.example.infosystemcollege;
}